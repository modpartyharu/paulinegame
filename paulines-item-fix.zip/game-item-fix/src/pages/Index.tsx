import PaulineGame from '../components/PaulineGame';

const Index = () => {
  return <PaulineGame />;
};

export default Index;
